//
//  OBSUploadFileModel.h
//  OBS
//
//  Created by MaxZhang on 11/12/2017.
//  Copyright © 2017 obs. All rights reserved.
//

#ifndef OBSUploadFileModel_h
#define OBSUploadFileModel_h
#import "OBSBaseModel.h"
#import "OBSBaseNetworking.h"
#import "OBSClient.h"
#import "OBSServiceBaseModel.h"
#import "OBSServiceConstDefinition.h"
#import "OBSCallback.h"
@class OBSAbstractEncryption;

#pragma mark - request

/**
 断点续传
 */
@protocol OBSUploadFileProtocol<NSObject>
@required

/**
 桶名
 */
@property (nonatomic, strong, nonnull) NSString *bucketName;

/**
 对象名
 */
@property (nonatomic, strong, nonnull) NSString *objectKey;

/**
 访问策略
 */
@property (nonatomic, assign) OBSACLPolicy objectACLPolicy;

/**
 存储类型
 */
@property (nonatomic, assign) OBSStorageClass storageClass;

/**
 元数据
 */
@property (nonatomic, strong, nullable) NSDictionary *metaDataDict;

/**
 重定向站点
 */
@property (nonatomic, strong, nonnull) NSString *websiteRedirectLocation;

/**
 加密方式
 */
@property (nonatomic, strong, nonnull) __kindof OBSAbstractEncryption *encryption;

/**
 上传文件地址
 */
@property (nonatomic, strong, nonnull) NSString *uploadFilePath;

/**
 上传进度
 */
@property (atomic, copy, nonnull) OBSNetworkingUploadProgressBlock uploadProgressBlock;

/**
 开启断点续传
 */
@property (nonatomic, assign) BOOL enableCheckpoint;

/**
 开启MD5校验
 */
@property (nonatomic, assign) BOOL enableMD5Check;

/**
 开启分段MD5校验
 */
@property (nonatomic, assign) BOOL enablePartMD5Check;

/**
 设置断点续传模式下，记录上传进度的文件
 */
@property (nonatomic, strong, nonnull) NSString *checkpointFilePath;

/**
 分段大小
 */
@property (nonatomic, strong, nonnull) NSNumber *partSize;

/**
 MIME类型
 */
@property (nonatomic, assign) OBSContentType contentType;

/**
 上传回调
 */
@property (nonatomic, nullable) OBSCallback* callback;
/**
 x-obs-forbid-overwrite 头域
 */
@property (nonatomic, nullable) NSString * forbid_overwrite;

@end


/**
 断点续传request
 */
@interface OBSUploadFileRequest: OBSBaseRequest<OBSUploadFileProtocol>

/**
 上传数据
 */
@property (nonatomic, strong) NSData *uploadAllData; 

@property (nonatomic, strong) NSFileHandle *fileHandle;
/**
 上传路径，避免多次重新读取数据映射造成内存问题
 */
@property (nonatomic, strong) NSString *lastUploadFilePath;  

/**
 桶名
 */
@property (nonatomic, strong, nonnull) NSString *bucketName;

/**
 对象key
 */
@property (nonatomic, strong, nonnull) NSString *objectKey;

/**
 对象ACL
 */
@property (nonatomic, assign) OBSACLPolicy objectACLPolicy;

/**
 存储模式
 */
@property (nonatomic, assign) OBSStorageClass storageClass;

/**
 元数据
 */
@property (nonatomic, strong, nullable) NSDictionary *metaDataDict;

/**
 网址重定向
 */
@property (nonatomic, strong, nonnull) NSString *websiteRedirectLocation;

/**
 加密方式
 */
@property (nonatomic, strong, nonnull) __kindof OBSAbstractEncryption *encryption;

/**
 上传文件路径
 */
@property (nonatomic, strong, nonnull) NSString *uploadFilePath;

/**
 上传回调
 */
@property (atomic, copy, nonnull) OBSNetworkingUploadProgressBlock uploadProgressBlock;

/**
 是否支持断点续传
 */
@property (nonatomic, assign) BOOL enableCheckpoint;

/**
 文件MD5校验
 */
@property (nonatomic, assign) BOOL enableMD5Check;

/**
 设置断点续传模式下，记录上传进度的文件
 */
@property (nonatomic, strong, nonnull) NSString *checkpointFilePath;

/**
 分段大小
 */
@property (nonatomic, strong, nonnull) NSNumber *partSize;

/**
 MIME类型
 */
@property (nonatomic, assign) OBSContentType contentType;

/**
 自定义MIME类型
 */
@property (nonatomic, strong, nonnull) NSString *customContentType;

/**
 最终映射MIME类型
 */
@property (nonatomic, strong, nonnull) NSString *finalContentType;

/**
 通过cancel方法暂停上传后，是否自动取消断点续传任务，并且删除本地记录上传进度的文件
 */
@property (nonatomic, assign) BOOL needAbortUploadFileAfterCancel;

/**
 断点续传上传中分段上传任务的失败后重试间隔（单位ms）
 */
@property (nonatomic, assign) NSInteger uploadPartRetryIntervalMs;
/**
 断点续传上传中每个分段上传任务的最大重试次数
 */
@property (nonatomic, assign) NSInteger maxUploadPartRetryCount;
/**
 上传回调
 */
@property (nonatomic, nullable) OBSCallback* callback;
/**
 x-obs-forbid-overwrite 头域
 */
@property (nonatomic, nullable) NSString * forbid_overwrite;
/**
 初始化断点续传request

 @param bucketName 桶名
 @param objectKey 对象key
 @param uploadFilePath 上传文件路径
 @return 断点续传request
 */
-(instancetype)initWithBucketName:(NSString*) bucketName objectKey:(NSString*) objectKey uploadFilePath:(NSString*) uploadFilePath;
@end

    //response
#pragma mark - response

/**
 断点续传response
 */
@interface OBSUploadFileResponse: OBSServiceResponse

/**
 上传对象etag
 */
@property (nonatomic, strong, nonnull) NSString *etag;

/**
 加密方式
 */
@property (nonatomic, strong, nonnull) __kindof OBSAbstractEncryption *encryption;
@end

    //client method
#pragma mark - client method
@interface OBSClient(uploadFile)

/**
 上传文件

 @param request 断点续传request
 @param completionHandler 断点续传回调
 @return OBSBFTask
 */
- (OBSBFTask*)uploadFile:(__kindof OBSBaseRequest<OBSUploadFileProtocol>*)request
         completionHandler:(void (^)(OBSUploadFileResponse  * response, NSError * error))completionHandler;
@end

#endif /* OBSUploadFileModel_h */
